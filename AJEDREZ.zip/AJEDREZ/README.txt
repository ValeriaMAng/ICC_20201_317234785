
Abrir una terminal en la carpeta AJEDREZ

- Para complar escribir el comando:  gradle build

- Para ejecutar escribir el comando: gradle run
