package chess.pieces;
import chess.items.Posicion;
import chess.items.ColorEnum;
import chess.items.Tablero;
import java.util.LinkedList;

/**
* Clase que modela una Reina (pieza de ajedrez)
*@author Manjarrez Angeles Valeria Fernanda
*/
public class Reina extends Torre{

  /**
  * Constructor para la clase Reina
  */
  public Reina(Posicion posicion, ColorEnum color){
    super(posicion, color);
    this.tipoPieza = EnumPieza.REINA;
  }

  /**
  *Movimientos legales de la Reina
  */
  public LinkedList<Posicion> obtenerMovimientosLegales(){
    Tablero tablero = Tablero.getInstance();
    if(this.movimientosLegales == null){
      LinkedList<Posicion> movimientosLegales = super.obtenerMovimientosLegales();

      int posY  = this.posicion.getY()+1;
      for(int i = this.posicion.getX()+1; i < 8; i++){
        Posicion siguientePosLegal = new Posicion(i, posY++);
        if(!this.estaDentroTablero(siguientePosLegal)) break;
        Pieza pieza = tablero.getPieza(siguientePosLegal);
        if(pieza.getColor().equals(this.getColor()))break;
        if(!pieza.getColor().equals(ColorEnum.NONE)){
            this.movimientosLegales.add(siguientePosLegal);
            break;
        }
        this.movimientosLegales.add(siguientePosLegal);
      }

      posY = this.posicion.getY();
      for(int i = this.posicion.getX()+1; i < 8; i++){
        Posicion siguientePosLegal = new Posicion(i, --posY);
        if(!this.estaDentroTablero(siguientePosLegal)) break;
        Pieza pieza = tablero.getPieza(siguientePosLegal);
        if(pieza.getColor().equals(this.getColor()))break;
        if(!pieza.getColor().equals(ColorEnum.NONE)){
            this.movimientosLegales.add(siguientePosLegal);
            break;
        }
        this.movimientosLegales.add(siguientePosLegal);
      }

      posY = this.posicion.getY() - 1;
      for(int i = this.posicion.getX()-1; i >= 0; i--){
        Posicion siguientePosLegal = new Posicion(i, posY--);
        if(!this.estaDentroTablero(siguientePosLegal)) break;
        Pieza pieza = tablero.getPieza(siguientePosLegal);
        if(pieza.getColor().equals(this.getColor()))break;
        if(!pieza.getColor().equals(ColorEnum.NONE)){
            this.movimientosLegales.add(siguientePosLegal);
            break;
        }
        this.movimientosLegales.add(siguientePosLegal);
      }

      posY = this.posicion.getY() + 1;
      for(int i = this.posicion.getX()-1; i >= 0; i--){
        Posicion siguientePosLegal = new Posicion(i, posY++);
        if(!this.estaDentroTablero(siguientePosLegal)) break;
        Pieza pieza = tablero.getPieza(siguientePosLegal);
        if(pieza.getColor().equals(this.getColor()))break;
        if(!pieza.getColor().equals(ColorEnum.NONE)){
            this.movimientosLegales.add(siguientePosLegal);
            break;
        }
        this.movimientosLegales.add(siguientePosLegal);
      }
    }
    return this.movimientosLegales;
  }

  /**
  * Método para comparar dos reinas
  *@param r - Reina a comparar
  *@return true si las reinas son iguales, false en otro caso
  **/
  @Override
  public boolean equals(Object r){
    if(!(r instanceof Reina)) return false;
    @SuppressWarnings("unchecked") Reina pieza = (Reina) r;
    if(pieza.getColor() == this.getColor() && this.getPosicion().equals(pieza.getPosicion())) return true;
    else return false;
  }
}
