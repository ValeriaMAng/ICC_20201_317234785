package chess.pieces;

/*
* Enumeración del el tipo de piezas en el tablero de ajedrez
*@author Manjarrez Angeles Valeria Fernanda
*/
public enum EnumPieza{

  PEON,
  ALFIL,
  REINA,
  REY,
  TORRE,
  CABALLO,
  NONE;

  /**
  * Método para imprimir la posición de las piezas en String
  */
  @Override public String toString() {
        switch(this){
          case NONE : return   "   ---   ";
          case PEON: return    "   Peón  ";
          case ALFIL: return   "  Alfil  ";
          case TORRE : return  "  Torre  ";
          case CABALLO: return " Caballo ";
          case REINA : return  "  Reina  ";
          case REY: return     "   Rey   ";
          default: throw new IllegalArgumentException();
        }
    }
}
