package chess.pieces;
import chess.items.*;
import java.util.LinkedList;

/*
* Clase que modela un Rey (pieza de ajedrez)
*@author Manjarrez Angeles Valeria Fernanda
*/
public class Rey extends Pieza{

  /**
  * Constructor para la clase Rey
  */
  public Rey(Posicion p, ColorEnum color){
    super(p, color);
    this.tipoPieza = EnumPieza.REY;
  }

  /**
  * Movimientos legales del Rey
  */
  public LinkedList<Posicion> obtenerMovimientosLegales(){
    Tablero tablero = Tablero.getInstance();
    if(this.movimientosLegales == null){
      this.movimientosLegales = new LinkedList<Posicion> ();

      int x = this.posicion.getX() -1;
      int y = this.posicion.getY() -1;
      for(int i = 0; i <3; i++){
        for(int j = 0; j < 3; j++){
          Posicion siguientePosLegal = new Posicion(x,y+j);
          if(this.estaDentroTablero(siguientePosLegal)) {
            Pieza pieza = tablero.getPieza(siguientePosLegal);
            if(!pieza.getColor().equals(this.getColor()))
              movimientosLegales.add(siguientePosLegal);
          }
        }
        x++;
      }
    }
    return this.movimientosLegales;
  }

  /**
  * Método para comparar dos reyes
  *@param r - Rey a comparar
  *@return true si los reyes son iguales, false en otro caso
  **/
  @Override
  public boolean equals(Object r){
    if(!(r instanceof Rey)) return false;
    @SuppressWarnings("unchecked") Rey pieza = (Rey) r;
    if(pieza.getColor() == this.getColor() && this.getPosicion().equals(pieza.getPosicion())) return true;
    else return false;
  }
}
