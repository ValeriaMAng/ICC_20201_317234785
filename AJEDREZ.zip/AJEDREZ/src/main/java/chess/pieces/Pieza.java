package chess.pieces;
import chess.items.*;
import java.util.LinkedList;

/**
* Clase Abstracta que modela una pieza de ajedrez
*@author Manjarrez Angeles Valeria Fernanda
*/
public abstract class Pieza{

  protected Posicion posicion;
  protected EnumPieza tipoPieza;
  protected ColorEnum colorPieza;
  protected LinkedList<Posicion> movimientosLegales;

  /**
  * Constructor de la clase Pieza
  */
  public Pieza(Posicion p, ColorEnum color){
    this.posicion = p;
    this.colorPieza = color;
  }

  /*
  * Método para mover la pieza
  *@param pos - Posición a mover
  */
  public void moverPieza(Posicion pos){
    if(this.esMovimientoLegal(pos)){
      this.posicion = pos;
      this.movimientosLegales = null;
    }
    return;
  }

  /**
  * Método para saber si un movimiento es legal
  *@param s - Posición a mover
  */
  public boolean esMovimientoLegal(Posicion s){
    if(this.movimientosLegales == null){
      this.movimientosLegales = new LinkedList<>();
    }
    return movimientosLegales.contains(s) ? true : false;
  }

  /**
  * Método para comparar dos piezas
  *@param p - Pieza a comparar
  *@return true si las piezas son iguales, false en otro caso
  */
  @Override
  public boolean equals(Object p){
    if((p instanceof Pieza)) return false;
    @SuppressWarnings("unchecked") Pieza pieza = (Pieza) p;
    if(pieza.getPosicion() != this.posicion || pieza.getTipo() != this.tipoPieza) return false;
    return true;
  }

  /**
  * Método para obtener la posición de una pieza
  */
  public Posicion getPosicion(){
    return this.posicion;
  }

  /**
  * Método para obtener los movimientos legales de cada pieza
  */
  public abstract LinkedList<Posicion> obtenerMovimientosLegales();

  /**
  * Método para saber de qué tipo es la pieza
  */
  public EnumPieza getTipo(){
    return this.tipoPieza;
  }

  /**
  * Método para obtener el color de cualquier pieza
  */
  public ColorEnum getColor(){
    return this.colorPieza;
  }

  /**
  * Método para obtener el String de la pieza
  */
  @Override
  public String toString(){
    return this.tipoPieza.toString();
  }

  /**
  * Método para ver si una pieza está dentro del tablero
  */
  public boolean estaDentroTablero(Posicion posicion){
    return posicion.getX()<8 && posicion.getX()>= 0 && posicion.getY() >= 0 && posicion.getY()<8;
  }
}
