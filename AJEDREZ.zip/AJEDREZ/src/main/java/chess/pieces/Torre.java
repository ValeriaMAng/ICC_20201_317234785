package chess.pieces;
import java.util.LinkedList;
import chess.items.*;

/**
* Clase que modela una Torre (pieza de ajedrez)
*@auhor Manjarrez Angeles Valeria Fernanda
*/
public class Torre extends Pieza{

  /*
  * Constructor de la clase Torre
  */
  public Torre(Posicion p, ColorEnum color){
    super(p, color);
    this.tipoPieza = EnumPieza.TORRE;
  }

  /**
  *Movimientos legales de la Torre
  */
  public LinkedList<Posicion> obtenerMovimientosLegales() {
        Tablero tablero = Tablero.getInstance();
        if (this.movimientosLegales == null) {
            this.movimientosLegales = new LinkedList<Posicion>();

            for(int i = this.posicion.getX()+1;i < 8; i++){
                Posicion siguientePosLegal = new Posicion(i, this.posicion.getY());
                if(!this.estaDentroTablero(siguientePosLegal)) break;
                Pieza pieza = tablero.getPieza(siguientePosLegal);
                if(pieza.getColor().equals(this.getColor()))break;
                if(!pieza.getColor().equals(ColorEnum.NONE)){
                    this.movimientosLegales.add(siguientePosLegal);
                    break;
                }
                this.movimientosLegales.add(siguientePosLegal);
            }

            for(int i = this.posicion.getX()-1;i >= 0; i--){
                Posicion siguientePosLegal = new Posicion(i, this.posicion.getY());
                if(!this.estaDentroTablero(siguientePosLegal)) break;
                Pieza pieza = tablero.getPieza(siguientePosLegal);
                if(pieza.getColor().equals(this.getColor()))break;
                if(!pieza.getColor().equals(ColorEnum.NONE)){
                    this.movimientosLegales.add(siguientePosLegal);
                    break;
                }
                this.movimientosLegales.add(siguientePosLegal);
            }

            for(int i = this.posicion.getY()+1;i < 8; i++){
                Posicion siguientePosLegal = new Posicion(this.posicion.getX(), i);
                if(!this.estaDentroTablero(siguientePosLegal)) break;
                Pieza pieza = tablero.getPieza(siguientePosLegal);
                if(pieza.getColor().equals(this.getColor()))break;
                if(!pieza.getColor().equals(ColorEnum.NONE)){
                    this.movimientosLegales.add(siguientePosLegal);
                    break;
                }
                this.movimientosLegales.add(siguientePosLegal);
            }


            for(int i = this.posicion.getY()-1;i >= 0; i--){
                Posicion siguientePosLegal = new Posicion(this.posicion.getX(), i);
                if(!this.estaDentroTablero(siguientePosLegal)) break;
                Pieza pieza = tablero.getPieza(siguientePosLegal);
                if(pieza.getColor().equals(this.getColor()))break;
                if(!pieza.getColor().equals(ColorEnum.NONE)){
                    this.movimientosLegales.add(siguientePosLegal);
                    break;
                }
                this.movimientosLegales.add(siguientePosLegal);
            }
        }

        return this.movimientosLegales;
    }

  /**
  * Método para comparar dos torres
  *@param t - Torre a comparar
  *@return true si las torres son iguales, false en otro caso
  */
  @Override
  public boolean equals(Object t){
    if(!(t instanceof Torre)) return false;
    @SuppressWarnings("unchecked") Torre torre = (Torre) t;
    if(torre.getColor() == this.getColor() && this.getPosicion().equals(torre.getPosicion())) return true;
    else return false;
  }
}
