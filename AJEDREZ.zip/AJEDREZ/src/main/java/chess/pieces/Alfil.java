package chess.pieces;
import chess.items.Posicion;
import chess.items.ColorEnum;
import chess.items.Tablero;
import java.util.LinkedList;

/**
* Clase que modela un Alfil
*@author Manjarrez Angeles Valeria Fernanda
*/
public class Alfil extends Pieza{

  /**
  * Constructor de la clase Alfil
  */
  public Alfil(Posicion posicion, ColorEnum color){
    super(posicion, color);
    this.tipoPieza = EnumPieza.ALFIL;
  }

  /**
  * Movimientos legales del Alfil
  */
  public LinkedList<Posicion> obtenerMovimientosLegales(){
    Tablero tablero = Tablero.getInstance();
    if(this.movimientosLegales == null){
      this.movimientosLegales = new LinkedList<Posicion>();

      int posY  = this.posicion.getY()+1;
      for(int i = this.posicion.getX()+1; i < 8; i++){
        Posicion siguientePosLegal = new Posicion(i, posY++);
        if(!this.estaDentroTablero(siguientePosLegal)) break;
        Pieza pieza = tablero.getPieza(siguientePosLegal);
        if(pieza.getColor().equals(this.getColor()))break;
        if(!pieza.getColor().equals(ColorEnum.NONE)){
            this.movimientosLegales.add(siguientePosLegal);
            break;
        }
        this.movimientosLegales.add(siguientePosLegal);
      }

      posY = this.posicion.getY()-1;
      for(int i = this.posicion.getX()+1; i < 8; i++){
        Posicion siguientePosLegal = new Posicion(i, posY--);
        if(!this.estaDentroTablero(siguientePosLegal)) break;
        Pieza pieza = tablero.getPieza(siguientePosLegal);
        if(pieza.getColor().equals(this.getColor()))break;
        if(!pieza.getColor().equals(ColorEnum.NONE)){
            this.movimientosLegales.add(siguientePosLegal);
            break;
        }
        this.movimientosLegales.add(siguientePosLegal);
      }

      /* Moviendo sobre la diagonal izquierda hacia arriba */
      posY = this.posicion.getY() - 1;
      for(int i = this.posicion.getX()-1; i >= 0; i--){
        Posicion siguientePosLegal = new Posicion(i, posY--);
        if(!this.estaDentroTablero(siguientePosLegal)) break;
        Pieza pieza = tablero.getPieza(siguientePosLegal);
        if(pieza.getColor().equals(this.getColor()))break;
        if(!pieza.getColor().equals(ColorEnum.NONE)){
            this.movimientosLegales.add(siguientePosLegal);
            break;
        }
        this.movimientosLegales.add(siguientePosLegal);
      }

      posY = this.posicion.getY() + 1;
      for(int i = this.posicion.getX()-1; i >= 0; i--){
        Posicion siguientePosLegal = new Posicion(i, posY++);
        if(!this.estaDentroTablero(siguientePosLegal)) break;
        Pieza pieza = tablero.getPieza(siguientePosLegal);
        if(pieza.getColor().equals(this.getColor()))break;
        if(!pieza.getColor().equals(ColorEnum.NONE)){
            this.movimientosLegales.add(siguientePosLegal);
            break;
        }
        this.movimientosLegales.add(siguientePosLegal);
      }
    }
    return this.movimientosLegales;
  }

  /** Método para comparar dos alfiles
  *@param a - Alfil a comparar
  *@return true si son iguales, false en otro caso
  **/
  @Override
  public boolean equals(Object a){
    if(!(a instanceof Alfil)) return false;
    @SuppressWarnings("unchecked") Alfil pieza = (Alfil) a;
    if(pieza.getColor() == this.getColor() && this.getPosicion().equals(pieza.getPosicion())) return true;
    else return false;
  }
}
