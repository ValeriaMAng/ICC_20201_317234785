package chess.pieces;
import java.util.LinkedList;
import chess.items.*;
/**
* Clase que modela una pieza vacia, Empty
*@author Manjarrez Angeles Valeria Fernanda
**/
public class Empty extends Pieza{

  /**
  * Constructor de la clase Empty
  */
  public Empty(Posicion p, ColorEnum color){
    super(p, color);
    this.tipoPieza = EnumPieza.NONE;
  }

  /**
  * Constructor de la clase Empty
  */
  public Empty(){
    super(new Posicion(0,0), ColorEnum.NONE);
  }
  
  /*
  * Movimientos legales de la pieza Empty
  */
  @Override
  public LinkedList<Posicion> obtenerMovimientosLegales(){
    return new LinkedList<>();
  }

  /**
  * Método para comparar dos piezas Empty
  * @param e - Empty a comparar
  * @return true si son iguales, false en otro caso
  */
  @Override
  public boolean equals(Object e){
    return (e instanceof Empty) ? true: false;
  }
}
