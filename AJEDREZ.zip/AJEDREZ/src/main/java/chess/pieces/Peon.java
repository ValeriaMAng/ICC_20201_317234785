package chess.pieces;
import chess.items.*;
import java.util.LinkedList;

/**
* Clase que modela un Peón
*@author Manjarrez Angeles Valeria Feranda
*/
public class Peon extends Pieza{

  /**
  * Constructor de la clase peón
  */
  public Peon(Posicion posicion, ColorEnum color){
    super(posicion, color);
    this.tipoPieza = EnumPieza.PEON;
  }

  /**
  * Método para verificar la posición
  * @param p - Posición
  * @param lista - LinkedList<Posicion>
  **/
  public void verificar(Posicion p, LinkedList<Posicion> lista){
    Tablero tablero = Tablero.getInstance();
    if(this.estaDentroTablero(p)) {
      Pieza pieza = tablero.getPieza(p);
      if(pieza.getColor().equals(ColorEnum.NONE)){
        lista.add(p);
      }
    }
    return;
  }

  /**
  * Método para verificar el ataque del Peón
  * @param p - Posicion
  * @param lista - LinkedList<Posicion>
  **/
  public void verificarAtaque(Posicion p, LinkedList<Posicion> lista){
    Tablero tablero = Tablero.getInstance();
    if(this.estaDentroTablero(p)){
      Pieza pieza = tablero.getPieza(p);
      if(!pieza.getColor().equals(ColorEnum.NONE))
        if(!(pieza.getColor().equals(this.getColor())))
          lista.add(p);
        else
          return;
      else
        return;
    }
    return;
  }

  /**
  * Movimientos legales del Peón
  */
  public LinkedList<Posicion> obtenerMovimientosLegales(){
    Tablero tablero = Tablero.getInstance();
    if (this.movimientosLegales == null) {
        this.movimientosLegales = new LinkedList<Posicion>();

        switch(this.getColor()){
          case NEGRO:
            Posicion siguientePosLegal = new Posicion(this.posicion.getX()+1, this.posicion.getY());
            verificar(siguientePosLegal, this.movimientosLegales);
            if(this.posicion.getX() == 1){
              Pieza pieza = tablero.getPieza(new Posicion(2,this.posicion.getY()));
              Pieza pieza2 = tablero.getPieza(new Posicion(3,this.posicion.getY()));
              if(pieza.getColor().equals(ColorEnum.NONE) && pieza2.getColor().equals(ColorEnum.NONE))
                verificar(new Posicion(this.posicion.getX()+2, this.posicion.getY()), this.movimientosLegales);
            }

            verificarAtaque(new Posicion(this.posicion.getX()+1, this.posicion.getY()-1), this.movimientosLegales);
            verificarAtaque(new Posicion(this.posicion.getX()+1, this.posicion.getY()+1), this.movimientosLegales);
            break;

          case BLANCO:
            siguientePosLegal = new Posicion(this.posicion.getX()-1, this.posicion.getY());
            verificar(siguientePosLegal, this.movimientosLegales);
            if(this.posicion.getX() == 6){
              Pieza pieza = tablero.getPieza(new Posicion(5,this.posicion.getY()));
              Pieza pieza2 = tablero.getPieza(new Posicion(4,this.posicion.getY()));
              if(pieza.getColor().equals(ColorEnum.NONE) && pieza2.getColor().equals(ColorEnum.NONE))
                verificar(new Posicion(this.posicion.getX()-2, this.posicion.getY()), this.movimientosLegales);
            }

            verificarAtaque(new Posicion(this.posicion.getX()-1, this.posicion.getY()-1), this.movimientosLegales);
            verificarAtaque(new Posicion(this.posicion.getX()-1, this.posicion.getY()+1), this.movimientosLegales);
            break;
        }
    } return this.movimientosLegales;
  }

  /**
  * Método para comparar dos peones
  *@param p - Peón a comparar
  *@return true si los peones son iguales, false en otro caso
  **/
  @Override
  public boolean equals(Object obj){
    if(!(obj instanceof Peon)) return false;
    @SuppressWarnings("unchecked") Peon pieza = (Peon) obj;
    if(pieza.getColor() == this.getColor() && this.getPosicion().equals(pieza.getPosicion())) return true;
    else return false;
  }
}
