package chess.pieces;
import chess.items.*;
import java.util.LinkedList;

/**
*Clase que modela un Caballo (pieza de ajedrez)
*@author Manjarrez Angeles Valeria Fernanda
*/
public class Caballo extends Pieza{

  /**
  * Constructor de la clase Caballo
  */
  public Caballo(Posicion p, ColorEnum color){
    super(p, color);
    this.tipoPieza = EnumPieza.CABALLO;
  }

  /**
  * Método para saber si se agrega una pieza a la lista
  */
  public void verificar(Posicion p, LinkedList<Posicion> lista){
    Tablero tablero = Tablero.getInstance();
    if(this.estaDentroTablero(p)){
      Pieza pieza = tablero.getPieza(p);
      if(pieza.getColor().equals(this.getColor())) return;
      else if(pieza.getColor().equals(ColorEnum.NONE) || !pieza.getColor().equals(this.getColor())) lista.add(p);
    }
    return;
  }

  /**
  * Movimientos legales del Caballo
  */
  public LinkedList<Posicion> obtenerMovimientosLegales(){
    if(this.movimientosLegales == null){
      this.movimientosLegales = new LinkedList<Posicion>();
      Posicion uno = new Posicion(this.posicion.getX()-2, this.posicion.getY()+1);
      this.verificar(uno, movimientosLegales);

      Posicion dos = new Posicion(this.posicion.getX()-2, this.posicion.getY()-1);
      this.verificar(dos, movimientosLegales);

      Posicion tres = new Posicion(this.posicion.getX()-1, this.posicion.getY()-2);
      this.verificar(tres, movimientosLegales);

      Posicion cuatro = new Posicion(this.posicion.getX()+1, this.posicion.getY()-2);
      this.verificar(cuatro, movimientosLegales);

      Posicion cinco = new Posicion(this.posicion.getX()+2, this.posicion.getY()-1);
      this.verificar(cinco, movimientosLegales);

      Posicion seis = new Posicion(this.posicion.getX()+2, this.posicion.getY()+1);
      this.verificar(seis, movimientosLegales);

      Posicion siete = new Posicion(this.posicion.getX()-1, this.posicion.getY()+2);
      this.verificar(siete, movimientosLegales);

      Posicion ocho = new Posicion(this.posicion.getX()+1, this.posicion.getY()+2);
      this.verificar(ocho, movimientosLegales);
    }
    return this.movimientosLegales;
  }

  /**
  * Método para comparar dos caballos
  * @param c - Caballo a comparar
  **/
  @Override
  public boolean equals(Object c){
    if(!(c instanceof Caballo)) return false;
    @SuppressWarnings("unchecked") Caballo pieza = (Caballo) c;
    if(pieza.getColor() == this.getColor() && this.getPosicion().equals(pieza.getPosicion())) return true;
    else return false;
  }

}
