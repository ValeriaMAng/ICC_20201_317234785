package chess.items;

/**
* Clase que determina la posición de las piezas en un tablero
* de ajedrez
*@author Manjarrez Angeles Valeria Fernanda
*/
public class Posicion{

  protected int x;
  protected int y;

  /**
  * Constructor de la clase Posicion
  *@param x - coordenada en x
  *@param y - coordenada en y
  */
  public Posicion(int x, int y){
    this.x = x;
    this.y = y;
  }

  /**
  * Método que compara dos posiciones
  *@param p - Objeto a comparar
  *@return true si su posición es la misma, false en otro caso
  **/
  @Override
  public boolean equals(Object p){
    if(!(p instanceof Posicion)) return false;
    @SuppressWarnings("unchecked") Posicion pos = (Posicion) p;
    if(pos.getX() == this.getX() && this.getY() == pos.getY()) return true;
    return false;
  }
  /**
  * Método para obtener la coordenada en x
  */
  public int getX(){
    return this.x;
  }

  /**
  * Método para obtener la coordenada en y
  */
  public int getY(){
    return this. y;
  }

  /**
  * Método para saber si una posición está dentro del tablero.
  * @param tam - Tamaño del tablero
  * @return true si está dentro del tablero, false en otro caso
  */
  public boolean estaFueraDelTablero(int tam){
    if(this.y>=tam || this.x >= tam) return false;
    if(this.y < 0 || this.x < 0 ) return false;
    return true;
  }

  /**
  * Método para obtener el string de la posición
  * @return String de la posición
  **/
  @Override
  public String toString(){
    return "Posición ( " + this.x + ", "+this.y+" )\n";
  }
}
