package chess.items;
//import chess.items.pieces;

/**Clase que nos da los colores de las piezas*/
public enum ColorEnum{
	BLANCO,
	NEGRO,
	NONE
	
}
