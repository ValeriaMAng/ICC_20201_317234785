package chess.items;
import chess.pieces.*;

/**
* Clase que modela un tablero de ajedrez y acomoda las piezas
*@author Manjarrez Angeles Valeria Fernanda
**/
public class Tablero{

  public int SIZE = 8;
  public Pieza[][] matriz;
  private static Tablero instance = null;

  /**
  *Constructor de la clase Tablero
  */
  private Tablero(){
    this.matriz = new Pieza[SIZE][SIZE];

    for(int i = 0; i < 8; i++){
      this.matriz[6][i] = new Peon(new Posicion(6,i), ColorEnum.BLANCO);
      this.matriz[1][i] = new Peon(new Posicion(1,i), ColorEnum.NEGRO);
    }

    this.matriz[7][2] = new Alfil(new Posicion(7,2), ColorEnum.BLANCO);
    this.matriz[0][2] = new Alfil(new Posicion(0,2), ColorEnum.NEGRO);
    this.matriz[7][5] = new Alfil(new Posicion(7,5), ColorEnum.BLANCO);
    this.matriz[0][5] = new Alfil(new Posicion(0,5), ColorEnum.NEGRO);

    this.matriz[7][0] = new Torre(new Posicion(7,0), ColorEnum.BLANCO);
    this.matriz[0][0] = new Torre(new Posicion(0,0), ColorEnum.NEGRO);
    this.matriz[7][7] = new Torre(new Posicion(7,7), ColorEnum.BLANCO);
    this.matriz[0][7] = new Torre(new Posicion(0,7), ColorEnum.NEGRO);

    this.matriz[7][1] = new Caballo(new Posicion(7,1), ColorEnum.BLANCO);
    this.matriz[0][1] = new Caballo(new Posicion(0,1), ColorEnum.NEGRO);
    this.matriz[7][6] = new Caballo(new Posicion(7,6), ColorEnum.BLANCO);
    this.matriz[0][6] = new Caballo(new Posicion(0,6), ColorEnum.NEGRO);

    this.matriz[7][4] = new Reina(new Posicion(7,4), ColorEnum.BLANCO);
    this.matriz[0][3] = new Rey(new Posicion(0,3), ColorEnum.NEGRO);
    this.matriz[7][3] = new Rey(new Posicion(7,3), ColorEnum.BLANCO);
    this.matriz[0][4] = new Reina(new Posicion(0,4), ColorEnum.NEGRO);

    for(int i = 2; i < 6; i++){
      for(int j = 0; j < 8; j++){
        this.matriz[i][j] = new Empty(new Posicion(i,j), ColorEnum.NONE);
      }
    }

  }

  /**
  * Método que regresar una instancia de tipo tablero
  */
  public static Tablero getInstance(){
    if(instance == null)
      instance = new Tablero();
    return instance;
  }

  /**
  * Método para convertir a string
  */
  @Override
  public String toString(){
    String result = "";
    for(int i = 0; i < SIZE; i++){
      for(int j = 0; j <SIZE; j++){
        result += " "+ matriz[i][j] +" ";
      }
      result+= "\n";
    }
    return result;
  }

  /**
  * Método para obtener una pieza
  * @param p - Coordenadas de su posición
  * @return La pieza deseada
  **/
  public Pieza getPieza(Posicion p, int i){
    return this.matriz[p.getY()][p.getX()];
  }

  /**
  * Método para obtener una pieza sin alternar las coordenadas
  * @param p - coordenadas de su posición
  * @return La pieza deseada
  **/
  public Pieza getPieza(Posicion p){
    return this.matriz[p.getX()][p.getY()];
  }

  /**
  * Método para obtener el tamaño del tablero
  */
  public int getTamaño(){return this.SIZE;}

  /**
  * Método para mover piezas
  * @param p - Posición actual
  * @param q - Nueva posición a mover
  * @return true si el movimiento es legal, false en otro caso
  **/
  public boolean move(Posicion a, Posicion b){
      if(!(a.estaFueraDelTablero(8)) || !(b.estaFueraDelTablero(8)))return false;
      Pieza piece = this.getPieza(a);
      piece.obtenerMovimientosLegales();
      if(!piece.esMovimientoLegal(b))return false;
      piece.moverPieza(b);
      this.matriz[a.getX()][a.getY()] = new Empty(a, ColorEnum.NONE);
      this.matriz[b.getX()][b.getY()] = piece;
      return true;
  }
}
