package gui;
import processing.core.PImage;
import processing.core.PApplet;
import java.util.List;
import java.util.LinkedList;
import chess.pieces.*;
import chess.items.*;

/**
*Clase que dibuja un tablero de ajedrez junto con sus piezas
*@author Manjarrez Angeles Valeria Fernanda
*/
public class ChessGUI extends PApplet{
    Tablero tablero = Tablero.getInstance();
    int PIXEL_SIZE = 70;
    PImage peonNegro, peonBlanco;
    PImage alfilNegro, alfilBlanco;
    PImage torreNegro, torreBlanco;
    PImage caballoNegro, caballoBlanco;
    PImage reinaNegro, reinaBlanco;
    PImage reyNegro, reyBlanco;

    ColorEnum turn = ColorEnum.BLANCO;
    Posicion selected = null;
    List<Posicion> movimientosLegales = new LinkedList<>();

    public static void main(String[] args) {
        PApplet.main("gui.ChessGUI");
    }

    /**
    *Tamaño del tablero
    */
    @Override
    public void settings(){
        size(550,550);
    }

    /**
    *Asignación de las imágenes a cada pieza
    */
    @Override
    public void setup(){
        System.out.println(tablero.toString());
        indicaTurno();
        peonBlanco = loadImage(getClass().getResource("/white-pawn-50.png").getPath());
        alfilBlanco = loadImage(getClass().getResource("/white-bishop-50.png").getPath());
        torreBlanco = loadImage(getClass().getResource("/white-rook-50.png").getPath());
        caballoBlanco = loadImage(getClass().getResource("/white-knight-50.png").getPath());
        reinaBlanco = loadImage(getClass().getResource("/white-queen-50.png").getPath());
        reyBlanco = loadImage(getClass().getResource("/white-king-50.png").getPath());
        peonNegro = loadImage(getClass().getResource("/black-pawn-50.png").getPath());
        alfilNegro = loadImage(getClass().getResource("/black-bishop-50.png").getPath());
        torreNegro = loadImage(getClass().getResource("/black-rook-50.png").getPath());
        caballoNegro = loadImage(getClass().getResource("/black-knight-50.png").getPath());
        reinaNegro = loadImage(getClass().getResource("/black-queen-50.png").getPath());
        reyNegro = loadImage(getClass().getResource("/black-king-50.png").getPath());
        dibujaTablero();
    }

    /**
    * Dibuja el tablero y los movimientos posibles
    */
    @Override
    public void draw(){
      dibujaTablero();
      dibujaMovimientosPosibles();
    }

    /**
    *Método que dibuja el tablero
    */
    public void dibujaTablero(){
        for (int i = 0; i < tablero.getTamaño();i++) {
            for (int j = 0; j < tablero.getTamaño(); j++) {
                if(i%2==0){
                    if(j%2==0)fill(50, 50, 50);
                    else fill(237, 202, 133);
                }else{
                    if(j%2==0)fill(237, 202, 133);
                    else fill(50, 50, 50);
                }
                rect(i * PIXEL_SIZE, j * PIXEL_SIZE, PIXEL_SIZE, PIXEL_SIZE);
                Pieza piece = tablero.getPieza(new Posicion(i, j), 0);
                drawPiece(piece);
            }
        }
    }
    /**
    * Método para dibujar una pieza en el tablero
    * @param p - pieza a dibujar
    **/
    public void drawPiece(Pieza piece){
        int x = piece.getPosicion().getY();
        int y = piece.getPosicion().getX();
        switch (piece.getTipo()){

          case PEON:
            if(piece.getColor().equals(ColorEnum.BLANCO))
                image(peonBlanco, x * PIXEL_SIZE, y * PIXEL_SIZE);
            if(piece.getColor().equals(ColorEnum.NEGRO))
                image(peonNegro, x * PIXEL_SIZE, y * PIXEL_SIZE);
            break;

          case ALFIL:
            if(piece.getColor().equals(ColorEnum.BLANCO))
                image(alfilBlanco, x * PIXEL_SIZE, y * PIXEL_SIZE);
            if(piece.getColor().equals(ColorEnum.NEGRO))
                image(alfilNegro, x * PIXEL_SIZE, y * PIXEL_SIZE);
            break;

          case TORRE:
            if(piece.getColor().equals(ColorEnum.BLANCO))
                image(torreBlanco, x * PIXEL_SIZE, y * PIXEL_SIZE);
            if(piece.getColor().equals(ColorEnum.NEGRO))
                image(torreNegro, x * PIXEL_SIZE, y * PIXEL_SIZE);
            break;

          case CABALLO:
            if(piece.getColor().equals(ColorEnum.BLANCO))
                image(caballoBlanco, x * PIXEL_SIZE, y * PIXEL_SIZE);
            if(piece.getColor().equals(ColorEnum.NEGRO))
                image(caballoNegro, x * PIXEL_SIZE, y * PIXEL_SIZE);
            break;

          case REINA:
            if(piece.getColor().equals(ColorEnum.BLANCO))
                image(reinaBlanco, x * PIXEL_SIZE, y * PIXEL_SIZE);
            if(piece.getColor().equals(ColorEnum.NEGRO))
                image(reinaNegro, x * PIXEL_SIZE, y * PIXEL_SIZE);
            break;

          case REY:
            if(piece.getColor().equals(ColorEnum.BLANCO))
                image(reyBlanco, x * PIXEL_SIZE, y * PIXEL_SIZE);
            if(piece.getColor().equals(ColorEnum.NEGRO))
                image(reyNegro, x * PIXEL_SIZE, y * PIXEL_SIZE);
            break;

            default:
                break;
        }
    }

    /**
    * Método para selecciónar y mover cualquier pieza haciendo click
    */
    @Override
    public void mouseClicked() {
        dibujaTablero();
        int x = mouseX / PIXEL_SIZE;
        int y = mouseY / PIXEL_SIZE;
        Posicion p = new Posicion(y,x);
        if(selected == null){
          selected = p;
          Pieza pieza = tablero.getPieza(p);
          this.movimientosLegales = pieza.obtenerMovimientosLegales();
          return;
        }else if(tablero.getPieza(p).getColor().equals(turn)){
          selected = p;
          Pieza pieza = tablero.getPieza(p);
          this.movimientosLegales = pieza.obtenerMovimientosLegales();
          return;
        }else{
          Pieza pieza2 = tablero.getPieza(p);
          if(tablero.getPieza(selected).getColor().equals(turn))
            if(this.tablero.move(selected, p)){
              if (turn.equals(ColorEnum.BLANCO))
                turn = ColorEnum.NEGRO;
              else
                turn = ColorEnum.BLANCO;
              selected = null;
              this.movimientosLegales = new LinkedList<>();
              indicaTurno();
              return;
            }
          this.movimientosLegales = new LinkedList<>();
        }

    }

    /**
    * Método para mostrar los movimientos posibles de la pieza seleccionada
    */
    public void dibujaMovimientosPosibles() {
        stroke(247, 136, 136);
        fill(245, 184, 184, 150);
        for (Posicion g : movimientosLegales) {
            int y = g.getX();
            int x = g.getY();
            rect(x * PIXEL_SIZE, y * PIXEL_SIZE, PIXEL_SIZE, PIXEL_SIZE);
        }
        stroke(0, 0, 0);
    }
    /**
    * Método que indica el turno
    */
    public void indicaTurno() {
        System.out.println("    /-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/");
        System.out.println("                   Turno: " + turn.toString().toLowerCase());
        System.out.println("    /-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/-/");
    }

}
